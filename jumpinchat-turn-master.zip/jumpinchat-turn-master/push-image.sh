IMAGE_TAG=registry.example.com/user/coturn

docker push ${IMAGE_TAG}
