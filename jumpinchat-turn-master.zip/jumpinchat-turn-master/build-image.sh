IMAGE_TAG=registry.example.com/user/coturn

docker build --no-cache -t ${IMAGE_TAG} .
