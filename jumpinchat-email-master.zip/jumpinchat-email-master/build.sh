#!/bin/sh

docker build --no-cache -t registry.example.com/user/jumpinchat-email .

