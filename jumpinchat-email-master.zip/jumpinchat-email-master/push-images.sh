#!/bin/sh

docker push registry.example.com/user/jumpinchat-email
