module.exports.activity = {
  SITE_BAN: 'Banlist',
  ROOM_CLOSE: 'RoomClose',
  REPORT_RESOLUTION: 'Report',
  NOTIFY: 'NOTIFY',
};
