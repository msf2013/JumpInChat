import roleSocket from './role.socket';

export default () => {
  roleSocket();
};
