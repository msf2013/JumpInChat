export const SERVER_ACTION = 'SERVER_ACTION';
export const VIEW_ACTION = 'VIEW_ACTION';
