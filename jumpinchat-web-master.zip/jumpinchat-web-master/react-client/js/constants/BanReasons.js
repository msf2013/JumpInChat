export default {
  BAN_BROADCAST_VIOLATION: 'Inappropriate broadcast',
  BAN_NUDITY: 'Nudity',
  BAN_RECORDING: 'Recording broadcasters',
  BAN_ABUSE: 'Abusing or promoting abuse',
  BAN_HARASSMENT: 'Harassing other members',
  BAN_UNDERAGE: 'Under age',
};
