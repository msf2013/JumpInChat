#!/bin/sh

NODE_ENV=production node /var/www/jic-homepage/keystone.js
