#!/bin/bash

echo "start janus"

env

/tmp/scripts/bootstrap.sh

/opt/janus/bin/janus
